<footer class="footer">
  <h6 class="footer-text">Al leer se sale del tiempo y se viaja estando quieto</h6>

  <div class="footer-social">
    <a href="#">Facebook</a>
    <a href="#">Twitter</a>
    <img src="<?php echo get_template_directory_uri()."/assets/imagenes/logo_luna.png;"; ?>" alt=" " class="footer-logo-luna" />
    <a href="#">Instagram</a>
    <a href="#">LinkedIn</a>
  </div>

  <div class="footer-derechos">Todos los derechos reservados © 2021</div>
  <?php wp_footer(); ?>
</footer>
</body>
</html>